from flask import render_template, redirect, request, session, flash
from flask_app.models.torta import Torta
from flask_app import app
from flask_app.models import usuarios


# Ruta para mostrar el dashboard
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/')
    tortas = Torta.get_all_by_user(session['user_id'])
    return render_template('dashboard.html', tortas=tortas)

# Ruta para guardar una nueva torta
@app.route('/tortas/nueva', methods=['POST'])
def nueva_torta():
    if 'user_id' not in session:
        return redirect('/')
    if not Torta.validate(request.form):
        return redirect('/dashboard')
    data = {
        "nombre": request.form['nombre'],
        "ingredientes": request.form['ingredientes'],
        "complemento": request.form['complemento'],
        "user_id": session['user_id']
    }
    Torta.save(data)
    return redirect('/dashboard')

# Ruta para editar una torta
@app.route('/tortas/editar/<int:id>', methods=['POST'])
def editar_torta(id):
    if 'user_id' not in session:
        return redirect('/')
    torta = Torta.get_by_id(id)
    if not torta or torta.user_id != session['user_id']:
        return redirect('/dashboard')
    if not Torta.validate(request.form):
        return redirect(f'/tortas/editar/{id}')
    data = {
        "id": id,
        "nombre": request.form['nombre'],
        "ingredientes": request.form['ingredientes'],
        "complemento": request.form['complemento']
    }
    Torta.update(data)
    return redirect('/dashboard')

# Ruta para eliminar una torta
@app.route('/tortas/eliminar/<int:id>')
def eliminar_torta(id):
    if 'user_id' not in session:
        return redirect('/')
    torta = Torta.get_by_id(id)
    if not torta or torta.user_id != session['user_id']:
        return redirect('/dashboard')
    Torta.delete(id)
    return redirect('/dashboard')

# Ruta para ver todas las tortas
@app.route('/tortas')
def ver_todas_tortas():
    # Aquí puedes implementar la lógica para mostrar todas las tortas
    pass
