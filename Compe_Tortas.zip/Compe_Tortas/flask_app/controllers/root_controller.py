from flask import redirect, render_template, request, session
from flask_app import app
from flask_app.models import usuarios
from flask_app.models import torta
from flask_app import bcrypt

from flask_app.utils.auth import session_required

from flask import render_template, redirect, request, session
from flask_app.models.torta import Torta

@app.route('/tortas/create', methods=['POST'])
def create_torta():
    if 'user_id' not in session:
        return redirect('/logout')

    # Validar datos del formulario (opcional)
    if not Torta.validate(request.form):
        return redirect('/dashboard')

    # Crear la torta en la base de datos
    data = {
        'nombre': request.form['nombre'],
        'ingredientes': request.form['ingredientes'],
        'complemento': request.form['complemento'],
        'user_id': session['user_id']
    }
    Torta.save(data)

    return redirect('/dashboard')


@app.route('/')
def index():
    return render_template('root/index.html')


@app.route('/register', methods=['POST'])
def register():
    if (not usuarios.usuario.validate(request.form)):
        return redirect('/')
    # Encriptar la contraseña
    nuevo_usuario = usuarios.usuario(request.form)
    nuevo_usuario.contraseña = bcrypt.generate_password_hash(
        request.form['contraseña'])
    user_id = usuarios.usuario.save(nuevo_usuario.__dict__())
    session['user_id'] = user_id
    return redirect('/dashboard')


@app.route('/login', methods=['POST'])
def login():

    user_id = usuarios.usuario.validate_login(request.form)
    if (not user_id):
        return redirect('/')
    session['user_id'] = user_id
    return redirect('/dashboard')


@app.route('/logout')
@session_required("/")
def logout():
    session.clear()
    return redirect('/')

@app.route('/dashboard')
@session_required("/")
def dashboard():
    user = usuarios.usuario.find_by_id(session['user_id'])
    tortas_list = torta.Torta.all()
    print(tortas_list)
    return render_template('root/dashboard.html', usuario=user, torta=tortas_list)