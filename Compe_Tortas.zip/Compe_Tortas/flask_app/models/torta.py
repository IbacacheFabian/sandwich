from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models.default_model import default_model
from dataclasses import dataclass
from typing import ClassVar
from flask import session
from dataclasses import InitVar, dataclass
from flask_app.models import usuarios

@dataclass(init=False)
class Torta(default_model):
    
    table_name: ClassVar[str] = "torta"  # Nombre de la tabla en la base de datos
    
    # Atributos de la clase
    nombre: str
    ingredientes: str
    complemento: str
    
    autor: InitVar["Torta.user_id"]

    likes: InitVar[dict]

    def __init__(self, data):
        self.id = data['id']
        self.nombre = data['nombre']
        self.ingredientes = data['ingredientes']
        self.complemento = data['complemento']
        self.user_id = data['owner_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        
    def get_autor(self):
        # Buscar el autor de la publicación por el owner_id en el modelo de usuarios
        autor = usuarios.usuario.find_by_id(self.id)
        self.autor = autor
        return self

    @classmethod
    def get_all_by_user(cls, user_id):
        query = f"SELECT * FROM {cls.table_name} WHERE user_id = %(user_id)s;"
        results = connectToMySQL('DB_NAME').query_db(query, {'user_id': user_id})
        return [cls(torta) for torta in results]

    @classmethod
    def get_by_id(cls, id):
        query = f"SELECT * FROM {cls.table_name} WHERE id = %(id)s;"
        result = connectToMySQL('DB_NAME').query_db(query, {'id': id})
        if len(result) > 0:
            return cls(result[0])
        return None

    @classmethod
    def save(cls, data):
        query = f"""
            INSERT INTO {cls.table_name} (nombre, ingredientes, complemento, created_at, updated_at)
            VALUES (%(nombre)s, %(ingredientes)s, %(complemento)s, NOW(), NOW());
        """
        return connectToMySQL('competencias_recetas_tortas').query_db(query, data)

    @classmethod
    def update(cls, data):
        query = f"""
            UPDATE {cls.table_name} 
            SET nombre = %(nombre)s, ingredientes = %(ingredientes)s, complemento = %(complemento)s, updated_at = NOW()
            WHERE id = %(id)s;
        """
        return connectToMySQL('DB_NAME').query_db(query, data)

    @classmethod
    def delete(cls, id):
        query = f"DELETE FROM {cls.table_name} WHERE id = %(id)s;"
        return connectToMySQL('DB_NAME').query_db(query, {'id': id})

    @staticmethod
    def validate(data):
        is_valid = True
        if len(data['nombre']) < 3:
            flash("El nombre debe tener al menos 3 caracteres.", "torta")
            is_valid = False
        if len(data['ingredientes']) < 3:
            flash("Los ingredientes deben tener al menos 3 caracteres.", "torta")
            is_valid = False
        if len(data['complemento']) < 3:
            flash("El complemento debe tener al menos 3 caracteres.", "torta")
            is_valid = False
        return is_valid

    @staticmethod
    def like(data):
        query = f"INSERT INTO likes (usuario_id, torta_id) VALUES (%(usuario_id)s, %(torta_id)s)"
        return Torta.run_query(query, data)