
from dataclasses import InitVar, dataclass
from datetime import date
from typing import ClassVar
from flask_app import app
from flask import flash
from flask_app.models.default_model import default_model
from flask_app.utils.validadores import error_message, esta_vacio
from flask_app.models import usuarios
from flask import session
from flask import render_template, redirect, request, session, flash


@app.route('/tortas/edit/<int:id>')
def edit_torta(id):
    # Lógica para editar una torta
    pass

@app.route('/tortas/delete/<int:id>')
def delete_torta(id):
    # Lógica para borrar una torta
    pass

@app.route('/tortas/all')
def all_tortas():
    # Lógica para mostrar todas las tortas
    pass

#codigo_____________________________________
@dataclass(init=False)
class Publicacion(default_model):
    # Nombre de la tabla
    table_name: ClassVar[str] = "torta"

    # Atributos de la clase
    nombre: str
    ingrediente: str
    complemento: str
    owner_id: int

    # Campos virtuales para las relaciones
    autor: InitVar["usuarios.usuario"]

    likes: InitVar[dict]


    @staticmethod
    def validate(data):
        # Variable que indica si los datos son válidos
        is_valid = True
        if (esta_vacio(data.get('nombre'))):
            is_valid = False
            flash("El nombre no puede estar vacío", "nombre")
        if (esta_vacio(data.get('ingredientes'))):
            is_valid = False
            flash("Los ingredientes no puede estar vacío", "ingredientes")
        if (esta_vacio(data.get('complemento'))):
            is_valid = False
            flash("El complemento no puede estar vacío", "complemento")
        if (esta_vacio(data.get('owner_id'))):
            is_valid = False
            flash("El owner_id no puede estar vacío", "owner_id")

        return is_valid

    @staticmethod
    def validate_2(data):

        error_nombre = not error_message(
            True, "El nombre no puede estar vacío", "nombre")(esta_vacio)(data.get('nombre'))
        error_ingredientes = not error_message(
            True, "La ingredientes no puede estar vacía", "ingredientes")(esta_vacio)(data.get('ingredientes'))
        error_complemento = not error_message(
            True, "El complemento no puede estar vacío", "complemento")(esta_vacio)(data.get('complemento'))
        error_owner_id = not error_message(
            True, "El owner_id no puede estar vacío", "owner_id")(esta_vacio)(data.get('owner_id'))

        return error_nombre and error_ingredientes and error_complemento and error_owner_id

    def get_autor(self):
        # Buscar el autor de la publicación por el owner_id en el modelo de usuarios
        autor = usuarios.usuario.find_by_id(self.owner_id)
        self.autor = autor
        return self
    
    def __init__(self, data):
        super().__init__(data)
        if (data.get('owner_id')):
            self.get_autor()
        self.get_likes()

    def get_likes(self):
        # Query
        query = f"SELECT * FROM likes WHERE publicacion_id = %(id)s"
        # Ejecutar query
        likes = self.run_query(query, self.__dict__())
        print(likes)
        likes_list = []
        for like in likes:
            likes_list.append(like['usuario_id'])
        self.likes = {
            'count': len(likes_list),
            'list': likes_list
        }    

    @staticmethod
    def like(data):
        query = f"INSERT INTO likes (usuario_id, torta_id) VALUES (%(usuario_id)s, %(torta_id)s)"
        return Publicacion.run_query(query, data)