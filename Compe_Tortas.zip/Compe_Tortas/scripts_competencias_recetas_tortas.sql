-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema competencias_recetas_tortas
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema competencias_recetas_tortas
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `competencias_recetas_tortas` DEFAULT CHARACTER SET utf8 ;
USE `competencias_recetas_tortas` ;

-- -----------------------------------------------------
-- Table `competencias_recetas_tortas`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `competencias_recetas_tortas`.`usuario` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `apellido` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `contraseña` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `competencias_recetas_tortas`.`torta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `competencias_recetas_tortas`.`torta` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(255) NOT NULL,
  `ingredientes` TEXT(1000) NOT NULL,
  `complemento` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `owner_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_torta_usuario_idx` (`owner_id` ASC) VISIBLE,
  CONSTRAINT `fk_torta_usuario`
    FOREIGN KEY (`owner_id`)
    REFERENCES `competencias_recetas_tortas`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `competencias_recetas_tortas`.`Likes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `competencias_recetas_tortas`.`Likes` (
  `usuario_id` INT NOT NULL,
  `torta_id` INT NOT NULL,
  PRIMARY KEY (`usuario_id`, `torta_id`),
  INDEX `fk_usuario_has_torta_torta1_idx` (`torta_id` ASC) VISIBLE,
  INDEX `fk_usuario_has_torta_usuario1_idx` (`usuario_id` ASC) VISIBLE,
  CONSTRAINT `fk_usuario_has_torta_usuario1`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `competencias_recetas_tortas`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_has_torta_torta1`
    FOREIGN KEY (`torta_id`)
    REFERENCES `competencias_recetas_tortas`.`torta` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
